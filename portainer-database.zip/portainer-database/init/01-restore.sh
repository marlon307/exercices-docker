#!/bin/sh
set -eu
dump=/backup/database.dump
[ -f "$dump" ] || { echo >&2 "Missing $dump. Keep data/database.dump in the deployment folder"; exit 1; }
pg_restore --dbname="$POSTGRES_DB" --username="$POSTGRES_USER" --no-owner --no-privileges --exit-on-error "$dump"
