# PostgreSQL anonimizado para Portainer

Este pacote contém uma cópia anonimizada do banco de produção, com dados fictícios adicionais para testes.

O dump não contém sessões ativas, contas OAuth, tokens de autenticação, tokens de verificação, inscrições push, e-mails reais ou telefones reais.

## Estrutura obrigatória

```text
portainer-database/
├── compose.yml
├── .env.example
├── README.md
├── MANIFEST.txt
├── data/
│   └── database.dump
└── init/
    └── 01-restore.sh
```

Não copie somente o `compose.yml`: os diretórios `data` e `init` também são necessários.

## Executar localmente

Entre na pasta:

```bash
cd portainer-database
```

Crie o arquivo de configuração:

```bash
cp .env.example .env
```

Edite o `.env`:

```env
POSTGRES_DB=cut_local
POSTGRES_USER=cut
POSTGRES_PASSWORD=troque-por-uma-senha-forte
POSTGRES_PORT=5432
POSTGRES_BIND_IP=127.0.0.1
```

Inicie o banco:

```bash
docker compose up -d --wait
```

Verifique o estado e os logs:

```bash
docker compose ps
docker compose logs -f postgres
```

O PostgreSQL deve aparecer como `healthy`.

Para uma aplicação executada diretamente no servidor:

```env
DATABASE_URL=postgresql://cut:SUA_SENHA@127.0.0.1:5432/cut_local
```

Para uma aplicação na mesma rede Docker:

```env
DATABASE_URL=postgresql://cut:SUA_SENHA@postgres:5432/cut_local
```

Substitua `SUA_SENHA` pelo valor de `POSTGRES_PASSWORD`.

## Executar no Portainer usando Git

Esta é a opção recomendada.

1. Coloque a pasta `portainer-database` em um repositório privado.
2. No Portainer, acesse **Stacks**.
3. Clique em **Add stack**.
4. Escolha **Repository**.
5. Informe a URL e as credenciais do repositório.
6. Em **Compose path**, informe `portainer-database/compose.yml`.
7. Adicione as variáveis de ambiente.
8. Clique em **Deploy the stack**.

Variáveis:

```env
POSTGRES_DB=cut_local
POSTGRES_USER=cut
POSTGRES_PASSWORD=coloque-uma-senha-forte
POSTGRES_PORT=5432
POSTGRES_BIND_IP=127.0.0.1
```

Use um repositório privado porque, embora anonimizado, o dump contém dados estruturais derivados do ambiente de produção.

## Executar com a pasta copiada para o servidor

Copie a pasta inteira:

```bash
scp -r portainer-database usuario@servidor:/opt/portainer-database
```

No servidor:

```bash
cd /opt/portainer-database
cp .env.example .env
```

Edite o `.env` e execute:

```bash
docker compose up -d --wait
```

Colar somente o conteúdo do `compose.yml` no Web Editor do Portainer não envia automaticamente `database.dump` e `01-restore.sh`. Esses arquivos precisam existir no servidor ou vir do repositório Git.

## Segurança de rede

Por padrão, o PostgreSQL é publicado apenas em:

```text
127.0.0.1:5432
```

Isso impede conexões diretas pela internet. Não altere para `0.0.0.0` sem firewall, VPN ou outra proteção adequada.

Se aplicação e banco estiverem na mesma Stack ou rede Docker, remova a seção `ports` do `compose.yml`. A aplicação acessará o banco internamente em `postgres:5432`.

## Parar e iniciar

Pare os containers preservando os dados:

```bash
docker compose down
```

Inicie novamente:

```bash
docker compose up -d --wait
```

## Restaurar o dump novamente

A restauração automática executa somente quando o volume do PostgreSQL está vazio.

Para apagar o banco atual e restaurar o dump novamente:

```bash
docker compose down -v
docker compose up -d --wait
```

Atenção: `docker compose down -v` apaga permanentemente o banco armazenado no volume dessa Stack.

Antes de usar esse comando, confirme a pasta e a configuração:

```bash
pwd
docker compose config
```

## Verificar os dados

Abra o terminal do PostgreSQL:

```bash
docker compose exec postgres psql -U cut -d cut_local
```

Consultas úteis:

```sql
SELECT count(*) FROM users;
SELECT count(*) FROM establishment;
SELECT count(*) FROM schedules;
```

Saia do PostgreSQL com:

```text
\q
```

Execute uma consulta diretamente com:

```bash
docker compose exec postgres \
  psql -U cut -d cut_local \
  -c "SELECT count(*) FROM schedules;"
```

## Alterar a porta

Se `5432` estiver ocupada, altere o `.env`:

```env
POSTGRES_PORT=5433
```

A conexão pelo servidor passa a ser:

```text
postgresql://cut:SUA_SENHA@127.0.0.1:5433/cut_local
```

A porta interna entre containers continua sendo `5432`.

## Problemas comuns

### `POSTGRES_PASSWORD is missing`

Configure no `.env` ou nas variáveis da Stack:

```env
POSTGRES_PASSWORD=uma-senha-forte
```

Depois execute novamente:

```bash
docker compose up -d --wait
```

### O banco subiu sem tabelas

Verifique os logs:

```bash
docker compose logs postgres
docker compose logs backup-loader
```

Confira os arquivos obrigatórios:

```bash
ls -lh data/database.dump
ls -lh init/01-restore.sh
```

Se o volume foi criado durante uma inicialização com erro:

```bash
docker compose down -v
docker compose up -d --wait
```

### A porta já está em uso

Altere no `.env`:

```env
POSTGRES_PORT=5433
```

Recrie os containers:

```bash
docker compose down
docker compose up -d --wait
```

### A aplicação não conecta

Se a aplicação estiver em outro container, não use `127.0.0.1`. Use:

```env
DATABASE_URL=postgresql://cut:SUA_SENHA@postgres:5432/cut_local
```

Confirme que aplicação e PostgreSQL estão na mesma rede Docker.

## Dados incluídos

O banco contém:

- usuários anonimizados;
- estabelecimentos anonimizados;
- clientes fictícios;
- profissionais fictícios;
- serviços fictícios;
- agendamentos passados e futuros;
- relacionamentos preservados para testes.

Sessões, contas OAuth, tokens de autenticação e inscrições push foram removidos.
